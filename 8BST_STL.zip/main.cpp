//
// Created by Святослав on 10.03.2024.
//

#include <iostream>
#include "Tree.h"

int main() {
    
    Tree<int> a;
    a.insert(5);
    a.insert(3);
    a.insert(2);
    a.insert(4);
    a.insert(6);
}